﻿Console.WriteLine("ingrese el número de estudiantes");
int estudiantes;
while (!int.TryParse(Console.ReadLine(), out estudiantes) || estudiantes <= 0)
{
    Console.WriteLine("ingrese un número de estudiantes válido");
}

Console.WriteLine("ingrese la cantidad de evaluaciones");
int evaluaciones;
while (!int.TryParse(Console.ReadLine(), out evaluaciones) || evaluaciones <= 0)
{
    Console.WriteLine("ingrese un número de evaluaciones válido");
}

int[,] matriz = new int[estudiantes, evaluaciones];
int notaAlta = int.MinValue;

for (int i = 0; i < estudiantes; i++)
{
    for (int j = 0; j < evaluaciones; j++)
    {
        Console.WriteLine($"ingrese la nota del estudiante {i + 1}, evaluación {j + 1}");
        int nota;
        while (!int.TryParse(Console.ReadLine(), out nota))
        {
            Console.WriteLine("ingrese una nota válida");
        }
        matriz[i, j] = nota;

        if (nota > notaAlta)
        {
            notaAlta = nota;
        }
    }
}

Console.WriteLine($"La nota más alta obtenida en todo el grupo es: {notaAlta}");
