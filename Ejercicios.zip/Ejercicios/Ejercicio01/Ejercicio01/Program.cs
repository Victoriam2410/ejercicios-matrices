﻿//Solicite al usuario la cantidad de zonas (filas) y la cantidad de días (columnas). Luego, permita ingresar las temperaturas registradas y muestre la información en forma de tabla organizada.
using static System.Net.WebRequestMethods;

Console.WriteLine("Ingrese la cantidad de zonas");
int fzonas;
while (!int.TryParse(Console.ReadLine(), out fzonas)|| fzonas <0)
    {
    Console.WriteLine("ingrese una zona valida");
}
Console.WriteLine("ingrese la cantidad de días");
int dias;
while (!int.TryParse(Console.ReadLine(), out dias) || dias < 0)
{
    Console.WriteLine("ingrese dia valido");

}
int[,] temperaturas = new int [fzonas, dias];
for (int i = 0; i < fzonas; i++)
{
    for (int j = 0; j < dias; j++)
    {
        Console.WriteLine($"ingrese los valores");
        temperaturas[i, j] = int.Parse(Console.ReadLine());
        
    }
}
Console.WriteLine("La tabla es: ");
for (int i = 0; i < fzonas; i++)
{
    for (int j = 0; j < dias; j++)
    {
        Console.Write(temperaturas[i, j] + "|");
    }
    Console.WriteLine();
}