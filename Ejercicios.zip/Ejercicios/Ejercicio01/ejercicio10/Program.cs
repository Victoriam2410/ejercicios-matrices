﻿Console.WriteLine("ingrese la cantidad de sucursales");
int sucursales;
while (!int.TryParse(Console.ReadLine(), out sucursales) || sucursales <= 0)
{
    Console.WriteLine("ingrese un numero de sucursales valido");
}

Console.WriteLine("ingrese la cantidad de productos");
int productos;
while (!int.TryParse(Console.ReadLine(), out productos) || productos <= 0)
{
    Console.WriteLine("ingrese un numero de productos valido");
}

int[,] matriz = new int[sucursales, productos];

for (int i = 0; i < sucursales; i++)
{
    for (int j = 0; j < productos; j++)
    {
        Console.WriteLine("ingrese los valores");
        matriz[i, j] = int.Parse(Console.ReadLine());
    }
}

Console.WriteLine("que sucursal desea buscar?");
int filaMostrar = int.Parse(Console.ReadLine());

if (filaMostrar >= 0 && filaMostrar < sucursales)
{
    Console.WriteLine($"Valores de la fila {filaMostrar}:");
    for (int j = 0; j < productos; j++)
    {
        Console.Write(matriz[filaMostrar, j] + " ");
    }
    Console.WriteLine();
}
else
{
    Console.WriteLine("La sucursal ingresada no existe.");
}
