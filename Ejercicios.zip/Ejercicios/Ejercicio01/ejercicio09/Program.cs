﻿Console.WriteLine("ingrese el numero de filas");
int filas;
while (!int.TryParse(Console.ReadLine(), out filas) || filas <= 0)
{
    Console.WriteLine("ingrese un numero de filas valido");
}

Console.WriteLine("ingrese el numero de columnas");
int columnas;
while (!int.TryParse(Console.ReadLine(), out columnas) || columnas <= 0)
{
    Console.WriteLine("ingrese un numero de columnas valido");
}

int[,] matriz = new int[filas, columnas];

for (int i = 0; i < filas; i++)
{
    for (int j = 0; j < columnas; j++)
    {
        Console.WriteLine("ingrese el valor");
        matriz[i, j] = int.Parse(Console.ReadLine());
    }
}

Console.WriteLine("que codigo desea buscar?");
int buscado = int.Parse(Console.ReadLine());
bool existe = false;

for (int i = 0; i < filas; i++)
{
    for (int j = 0; j < columnas; j++)
    {
        if (matriz[i, j] == buscado)
        {
            Console.WriteLine($"El codigo {buscado} existe en la fila {i} y columna {j}");
            existe = true;
        }
    }
}

if (!existe)
{
    Console.WriteLine("El codigo no existe.");
}
