﻿Console.WriteLine("ingrese la cantidad de estudiantes");
int cantEstudiantes;
while (!int.TryParse(Console.ReadLine(), out cantEstudiantes) || cantEstudiantes <= 0)
{
    Console.WriteLine("ingrese cantidad valida");
}

Console.WriteLine("ingrese la cantidad de días");
int cantDias;
while (!int.TryParse(Console.ReadLine(), out cantDias) || cantDias <= 0)
{
    Console.WriteLine("ingrese dia valido");
}

int[,] asistencia = new int[cantEstudiantes, cantDias];

for (int i = 0; i < cantEstudiantes; i++)
{
    for (int j = 0; j < cantDias; j++)
    {
        Console.WriteLine($"estudiante {i} dia {j} (1 asistio / 0 falto)");
        int valor;
        while (!int.TryParse(Console.ReadLine(), out valor) || (valor != 0 && valor != 1))
        {
            Console.WriteLine("solo 1 o 0");
        }
        asistencia[i, j] = valor;
    }
}

Console.WriteLine("que estudiante desea buscar?");
int elegido;
while (!int.TryParse(Console.ReadLine(), out elegido) || elegido < 0 || elegido >= cantEstudiantes)
{
    Console.WriteLine("estudiante no existe");
}

Console.WriteLine($"Asistencia del estudiante {elegido}:");
for (int j = 0; j < cantDias; j++)
{
    Console.Write(asistencia[elegido, j] + " ");
}
Console.WriteLine();
