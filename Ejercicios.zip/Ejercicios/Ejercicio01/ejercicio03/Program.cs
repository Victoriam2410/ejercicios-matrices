﻿Console.WriteLine("Ingrese la cantidad de zonas");
int apartamentos;
while (!int.TryParse(Console.ReadLine(), out apartamentos) || apartamentos < 0)
{
    Console.WriteLine("ingrese una zona valida");
}
Console.WriteLine("ingrese la cantidad de días");
int dias;
while (!int.TryParse(Console.ReadLine(), out dias) || dias < 0)
{
    Console.WriteLine("ingrese dia valido");

}
int[,] matriz = new int[apartamentos, dias];
int suma = 0;
for (int i = 0; i < apartamentos; i++)
{
    for (int j = 0; j < dias; j++)
    {
        Console.WriteLine($"ingrese los valores");
        matriz[i, j] = int.Parse(Console.ReadLine());
        suma += matriz[i, j]; 
    }
}
Console.WriteLine($"la suma total es: {suma}");
