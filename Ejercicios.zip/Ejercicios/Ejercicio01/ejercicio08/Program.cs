﻿Console.WriteLine("ingrese el numero de jugadores");
int jugadores;
while (!int.TryParse(Console.ReadLine(), out jugadores) || jugadores <= 0)
{
    Console.WriteLine("ingrese numero de jugadores valido");
}

Console.WriteLine("ingrese la cantidad de niveles");
int niveles;
while (!int.TryParse(Console.ReadLine(), out niveles) || niveles <= 0)
{
    Console.WriteLine("ingrese nivel valido");
}

int[,] matriz = new int[jugadores, niveles];
int puntajeMaximo = 0;

for (int i = 0; i < jugadores; i++)
{
    for (int j = 0; j < niveles; j++)
    {
        Console.WriteLine($"ingrese puntaje jugador {i} nivel {j}");
        int puntaje;
        while (!int.TryParse(Console.ReadLine(), out puntaje) || puntaje < 0)
        {
            Console.WriteLine("ingrese puntaje valido");
        }
        matriz[i, j] = puntaje;

        if (puntaje > puntajeMaximo)
        {
            puntajeMaximo = puntaje;
        }
    }
}

Console.WriteLine($"El puntaje mas alto en todo el juego es: {puntajeMaximo}");
