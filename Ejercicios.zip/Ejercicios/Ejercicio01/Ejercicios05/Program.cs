﻿Console.WriteLine("ingrese la cantidad de filas");
int filas;
while (!int.TryParse(Console.ReadLine(), out filas) || filas <= 0)
{
    Console.WriteLine("ingrese un número de filas válido");
}

Console.WriteLine("ingrese la cantidad de columnas");
int columnas;
while (!int.TryParse(Console.ReadLine(), out columnas) || columnas <= 0)
{
    Console.WriteLine("ingrese un número de columnas válido");
}

int[,] inventario = new int[filas, columnas];

for (int i = 0; i < filas; i++)
{
    for (int j = 0; j < columnas; j++)
    {
        Console.WriteLine($"ingrese el valor para la posición {i},{j}");
        int valor;
        while (!int.TryParse(Console.ReadLine(), out valor))
        {
            Console.WriteLine("ingrese un valor válido");
        }
        inventario[i, j] = valor;
    }
}

Console.WriteLine("ingrese el número a buscar");
int buscar;
while (!int.TryParse(Console.ReadLine(), out buscar))
{
    Console.WriteLine("ingrese un número válido");
}

bool encontrado = false;

for (int i = 0; i < filas; i++)
{
    for (int j = 0; j < columnas; j++)
    {
        if (inventario[i, j] == buscar)
        {
            Console.WriteLine($"El valor {buscar} existe y está en la fila {i}, columna {j}");
            encontrado = true;
        }
    }
}

if (!encontrado)
{
    Console.WriteLine("El valor buscado no existe en el inventario.");
}
