﻿Console.WriteLine("ingrese la cantidad de maquinas");
int maquinas;
while (!int.TryParse(Console.ReadLine(), out maquinas) || maquinas <= 0)
{
    Console.WriteLine("ingrese un numero valido");
}

Console.WriteLine("ingrese la cantidad de turnos");
int turnos;
while (!int.TryParse(Console.ReadLine(), out turnos) || turnos <= 0)
{
    Console.WriteLine("ingrese un numero valido");
}

int[,] matriz = new int[maquinas, turnos];
int totalProduccion = 0;

for (int i = 0; i < maquinas; i++)
{
    for (int j = 0; j < turnos; j++)
    {
        Console.WriteLine($"ingrese produccion maquina {i} turno {j}");
        int cantidad;
        while (!int.TryParse(Console.ReadLine(), out cantidad) || cantidad < 0)
        {
            Console.WriteLine("ingrese cantidad valida");
        }
        matriz[i, j] = cantidad;
        totalProduccion += cantidad;
    }
}

Console.WriteLine($"La produccion total de la fabrica es: {totalProduccion}");
