﻿using static System.Net.WebRequestMethods;

Console.WriteLine("ingrese la cantidad de productos");
int producto;
while (!int.TryParse(Console.ReadLine(), out producto) || producto < 0)
{
    Console.WriteLine("ingrese el numero de productos valido");
}
Console.WriteLine("ingrese la cantidad de días");
int dias;
while (!int.TryParse(Console.ReadLine(), out dias) || dias < 0)
{
    Console.WriteLine("ingrese dia valido");

}
int[,] matriz = new int[producto, dias];
for (int i = 0;i<producto; i++)
{
    for (int j = 0;j<dias; j++)
    {
        Console.WriteLine("ingrese los valores");
        matriz[i,j]= int .Parse(Console.ReadLine());
    }    
}
Console.WriteLine("que producto desea buscar? ");
int filaMostrar = int.Parse(Console.ReadLine());
    Console.WriteLine($"Valores de la fila {filaMostrar}:");
for (int i = 0; i < filaMostrar; i++)
{
    for (int j = 0; j < dias; j++)
    {
        Console.Write(matriz[i, j] + " ");
    }
    Console.WriteLine("El producto ingresado no existe.");
}